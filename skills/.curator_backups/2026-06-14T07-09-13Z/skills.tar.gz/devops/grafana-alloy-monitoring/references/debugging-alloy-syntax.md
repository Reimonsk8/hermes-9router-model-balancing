# Debugging Grafana Alloy Syntax Errors

- **Validation Tool**: Always use `alloy validate /path/to/config.alloy`. Never manually parse complex HCL logic.
- **HCL Syntax**: Alloy configuration (HCL) is strict about expression lists. 
  - Each item in a list `path_targets` must be comma-separated.
  - No trailing comma is allowed at the end of the last item in a list.
  - Double commas (e.g., `item},,`) or missing commas between list items are the most common source of validation failure.
- **System File Edits**: `write_file` will block edits to `/etc/`. Always use `sudo` with `sed` or Python-based file writing via `terminal()` if `write_file` blocks. 
- **Restarting on Alpine**: Use `sudo rc-service alloy restart`. Avoid `systemctl` on Alpine Linux.
- **Validation Loop Avoidance**:
  1. `read_file` to inspect the problematic line.
  2. Perform the fix using `sed` or `patch` (avoid manual re-writes of large config blocks if unnecessary).
  3. Immediately run `alloy validate`.
  4. Only proceed to restart if `validate` returns `exit_code: 0`.
