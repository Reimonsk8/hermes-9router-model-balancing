# Pi-hole + Alloy: Adding Pi-hole Metrics to Grafana Cloud

chopan-server runs Pi-hole (pihole-FTL on ports 53, 80, 443). Extend the Alloy config to add Pi-hole query statistics.

## Method: prometheus.exporter.pihole via loki.process (recommended for Grafana dashboards)

Query Pi-hole FTL database directly via cron job and forward as Prometheus text format:

### Script: /etc/alloy/pihole-metrics.py
```python
#!/usr/bin/env python3
import sqlite3, time

def get_pihole_stats():
    db_path = "/etc/pihole/pihole-FTL.db"
    try:
        conn = sqlite3.connect(db_path)
        c = conn.cursor()
        c.execute("SELECT COUNT(*) FROM queries"); total = c.fetchone()[0]
        c.execute("SELECT COUNT(*) FROM queries WHERE status IN (1,2)"); gravity = c.fetchone()[0]
        c.execute("SELECT COUNT(*) FROM queries WHERE status=3"); regex = c.fetchone()[0]
        conn.close()
        return {"total_queries": total, "blocked_queries": gravity + regex}
    except Exception as e:
        return {"error": str(e)}

stats = get_pihole_stats()
print(f'# HELP pihole_total_queries Total DNS queries\n# TYPE pihole_total_queries counter\npihole_total_queries {stats.get("total_queries", 0)}\n# HELP pihole_blocked_queries Total blocked DNS queries\n# TYPE pihole_blocked_queries counter\npihole_blocked_queries {stats.get("blocked_queries", 0)}')
```

### Expose via simple HTTP server (Python built-in)
```bash
# Start metrics server on :9100
nohup python3 -m http.server 9100 --directory /etc/alloy &>/var/log/alloy/pihole-metrics.log &
```
Then add to Alloy scrape config:
```alloy
prometheus.scrape "pihole_metrics" {
    targets = [{"__address__" = "127.0.0.1:9100", "__metrics_path__" = "/pihole-metrics.prom"}]
    forward_to = [prometheus.remote_write.grafana.receiver]
    scrape_interval = "5m"
}
```

## Method 2: Pi-hole log tail via Loki
Pi-hole logs blocked queries to /var/log/pihole.log:
```alloy
loki.source.file "pihole" {
    targets = [
        {path = "/var/log/pihole.log", unit = "pihole-FTL"},
    ]
    forward_to = [loki.process.pihole.receiver]
}

loki.process "pihole" {
    stage.regex {
        expression = `(?P<timestamp>\S+ \S+ \d+ \d+:\d+:\d+) \S+ pihole-FTL\[[\d]+\]: (?P<action>\w+)\[?\d*\]?: (?P<domain>\S+) from (?P<client>\S+)`
    }
    stage.labels { values = { action = "action", domain = "domain", client = "client" } }
    forward_to = [loki.write.grafana.receiver]
}
```

## Grafana Dashboard Panels
- Blocked ads: `rate(pihole_blocked_queries[5m]) * 300` (queries per 5min)
- Block rate: `rate(pihole_blocked_queries[5m]) / rate(pihole_total_queries[5m]) * 100`
- Top domains: Loki query `{unit="pihole-FTL"} |= "gravity" | json`

## Note
Grafana Labs has a community dashboard for Pi-hole + Prometheus. Search "Pi-hole" in Grafana Dashboards with Prometheus datasource.