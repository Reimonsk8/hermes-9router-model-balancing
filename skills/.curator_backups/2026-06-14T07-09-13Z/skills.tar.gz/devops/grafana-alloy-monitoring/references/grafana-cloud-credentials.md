# Grafana Cloud Credentials — Prometheus & Loki

## Prometheus Remote Write

**URL format:** `https://prometheus-prod-<hash>.grafana.net/api/v1/write`

Found at: grafana.com → Stacks → your stack → Connections → Prometheus → "Integration" tab or "How do I send data?" → remote_write URL.

**Username:** shown in the same UI panel (usually your numeric user ID or stack ID).

**Password:** NOT your Grafana password. Use the **Grafana Cloud API Key** (format: `glc_...`). 
- Get it from: grafana.com → Stacks → your stack → Security → API Keys → Create API Key → Role: MetricsPublisher
- The key starts with `glc_` — paste it as the password in the basic_auth block.

## Loki Remote Write

**URL format:** `https://logs-prod-<hash>.grafana.net/loki/api/v1/push`

Found at: grafana.com → Stacks → your stack → Connections → Loki → "Integration" tab.

**Username/Password:** Same pattern as Prometheus — use Loki API Key with `glc_...` prefix.

## Common Mistakes

| Mistake | Fix |
|---------|-----|
| Using account password | No — use `glc_...` API key |
| Wrong URL (prometheus vs logs subdomain) | Prometheus uses `prometheus-prod-`, Loki uses `logs-prod-` |
| Missing `/api/v1/write` or `/loki/api/v1/push` path | Must include the full path |
| Basic auth username = email | Use the numeric stack user or dedicated API key name |
| Env var with spaces in `env` file | Quote all values; use `export` prefix |

## Testing Credentials
```bash
curl -s -u "$PROMETHEUS_USERNAME:$PROMETHEUS_PASSWORD" \
  "$PROMETHEUS_REMOTE_WRITE_URL" -w "\n%{http_code}\n"
# Expected: 400 or 405 (POST expected, not GET) — credentials valid
# 401 = bad credentials
# 403 = valid credentials but forbidden
```

## Environment file security
```bash
chmod 600 /etc/alloy/env
chown root:root /etc/alloy/env
```
Never commit this file to git.