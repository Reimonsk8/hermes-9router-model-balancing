---
name: model-monitor
description: "Skills and scripts for monitoring LLM usage metrics dynamically in Hermes."
---

# Model Monitor Skill

This skill provides the structure and scripts for monitoring LLM model usage dynamically rather than relying on hardcoded lists.

### Sorting and Ordering
- **Ordering**: When displaying token usage, prioritize models with defined limits (sorted by consumption percentage) followed by models without limits. Use a tuple-based key for sorting: `(m['limit'] is None, m['pct'])` to ensure unconfigured models appear at the end.
- **Dynamic Discovery**: Always parse `~/.hermes/config.yaml` to retrieve the active model chain rather than using hardcoded lists.
- **Reporting**: When reporting token usage, always include a calculated total across all models to provide a clear view of overall consumption. (See `references/reporting-checklist.md`)



## References

- `scripts/context_exporter.py`: Exports context window usage metrics (used, max, remaining, utilization) to Prometheus format.
- `scripts/update_all_metrics.sh`: Unified script to run all monitoring tasks (auto-balance, Pi-hole, context).
- **Pitfall**: When adding metrics files to Alloy/Prometheus, ensure the file path is explicitly added to the `local.file_match` targets in `config.alloy` and that the service is restarted (`rc-service alloy restart` on Alpine) for changes to take effect.
