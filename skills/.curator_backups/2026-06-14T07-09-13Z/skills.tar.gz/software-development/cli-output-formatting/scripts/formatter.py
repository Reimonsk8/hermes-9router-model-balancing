#!/usr/bin/env python3
def beautiful_print(message):
    print("*" * 50)
    print(f"  {message}")
    print("*" * 50)
